package com.suddunagesh.yojanamitraa;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private WebView blogWebView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ProgressBar progressBar;
    private LinearLayout noInternetView;
    private Button btnRetry;
    private RecyclerView schemesRecyclerView;
    private EditText searchEditText;
    private BottomNavigationView bottomNavigation;
    private AdView adView;
    private YojanaAdapter adapter;
    private List<YojanaModel> allSchemes = new ArrayList<>();
    private final String BLOG_URL = "https://surgujasarkariyojanahelp.blogspot.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // 1. Initialize AdMob
        AdMobManager.getInstance().init(this);
        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        // 2. Setup views
        blogWebView = findViewById(R.id.blogWebView);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        progressBar = findViewById(R.id.progressBar);
        noInternetView = findViewById(R.id.noInternetView);
        btnRetry = findViewById(R.id.btnRetry);
        schemesRecyclerView = findViewById(R.id.schemesRecyclerView);
        searchEditText = findViewById(R.id.searchEditText);
        bottomNavigation = findViewById(R.id.bottomNavigation);

        // Setup RecyclerView
        schemesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new YojanaAdapter(this);
        schemesRecyclerView.setAdapter(adapter);

        loadOfflineSchemesData();
        setupWebView();

        // SwipeRefresh
        swipeRefreshLayout.setOnRefreshListener(() -> {
            if (blogWebView.getVisibility() == View.VISIBLE) {
                blogWebView.reload();
            } else {
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        btnRetry.setOnClickListener(v -> {
            noInternetView.setVisibility(View.GONE);
            blogWebView.setVisibility(View.VISIBLE);
            blogWebView.loadUrl(BLOG_URL);
        });

        // Search text watcher
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterSchemes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Bottom Navigation listener
        bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                showBlogWebView();
                return true;
            } else if (id == R.id.menu_schemes) {
                showSchemesList(false);
                return true;
            } else if (id == R.id.menu_search) {
                showSchemesList(true);
                return true;
            } else if (id == R.id.menu_favourite) {
                showSchemesList(false);
                Toast.makeText(this, "सभी 50+ योजनाएं ऑफलाइन उपलब्ध हैं!", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        // Load Home Blog by default
        showBlogWebView();
    }

    private void setupWebView() {
        WebSettings settings = blogWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        blogWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    blogWebView.setVisibility(View.GONE);
                    noInternetView.setVisibility(View.VISIBLE);
                }
            }
        });

        blogWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }
        });

        blogWebView.loadUrl(BLOG_URL);
    }

    private void showBlogWebView() {
        swipeRefreshLayout.setVisibility(View.VISIBLE);
        schemesRecyclerView.setVisibility(View.GONE);
        searchEditText.setVisibility(View.GONE);
    }

    private void showSchemesList(boolean focusSearch) {
        swipeRefreshLayout.setVisibility(View.GONE);
        schemesRecyclerView.setVisibility(View.VISIBLE);
        searchEditText.setVisibility(View.VISIBLE);
        if (focusSearch) {
            searchEditText.requestFocus();
        }
    }

    private void loadOfflineSchemesData() {
        try {
            InputStream is = getAssets().open("schemes.json");
            InputStreamReader reader = new InputStreamReader(is);
            Type listType = new TypeToken<List<YojanaModel>>(){}.getType();
            allSchemes = new Gson().fromJson(reader, listType);
            reader.close();
            adapter.setList(allSchemes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void filterSchemes(String query) {
        if (query.trim().isEmpty()) {
            adapter.setList(allSchemes);
            return;
        }
        List<YojanaModel> filtered = new ArrayList<>();
        String lower = query.toLowerCase().trim();
        for (YojanaModel y : allSchemes) {
            String searchable = (y.name_hi + " " + 
                (y.name_en != null ? y.name_en : "") + " " +
                (y.tagline_hi != null ? y.tagline_hi : "") + " " +
                (y.categoryName_hi != null ? y.categoryName_hi : "") + " " +
                (y.stateName_hi != null ? y.stateName_hi : "") + " " +
                (y.highlightAmount != null ? y.highlightAmount : "")).toLowerCase();
            
            boolean matches = searchable.contains(lower);
            if (!matches) {
                if (lower.contains("kisan") && searchable.contains("किसान")) matches = true;
                else if (lower.contains("mahtari") && searchable.contains("महतारी")) matches = true;
                else if (lower.contains("ladli") && searchable.contains("लाड़ली")) matches = true;
                else if (lower.contains("awas") && searchable.contains("आवास")) matches = true;
                else if (lower.contains("pension") && searchable.contains("पेंशन")) matches = true;
                else if (lower.contains("silai") && searchable.contains("सिलाई")) matches = true;
                else if (lower.contains("ayushman") && searchable.contains("आयुष्मान")) matches = true;
                else if (lower.contains("ujjwala") && searchable.contains("उज्ज्वला")) matches = true;
                else if (lower.contains("ration") && searchable.contains("राशन")) matches = true;
            }
            if (matches) {
                filtered.add(y);
            }
        }
        adapter.setList(filtered);
    }

    @Override
    public void onBackPressed() {
        if (blogWebView.getVisibility() == View.VISIBLE && blogWebView.canGoBack()) {
            blogWebView.goBack();
        } else if (schemesRecyclerView.getVisibility() == View.VISIBLE) {
            bottomNavigation.setSelectedItemId(R.id.menu_home);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (adView != null) adView.destroy();
        super.onDestroy();
    }
}
