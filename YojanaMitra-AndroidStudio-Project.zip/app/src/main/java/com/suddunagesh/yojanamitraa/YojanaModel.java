package com.suddunagesh.yojanamitraa;

import java.io.Serializable;
import java.util.List;

public class YojanaModel implements Serializable {
    public String id;
    public int schemeNumber;
    public String name_hi;
    public String name_en;
    public String tagline_hi;
    public String tagline_en;
    public String category;
    public String categoryName_hi;
    public String categoryName_en;
    public String state;
    public String stateName_hi;
    public String stateName_en;
    public String ministry_hi;
    public String ministry_en;
    public List<String> benefits_hi;
    public List<String> benefits_en;
    public List<String> eligibility_hi;
    public List<String> eligibility_en;
    public List<String> documents_hi;
    public List<String> documents_en;
    public List<String> howToApply_hi;
    public List<String> howToApply_en;
    public String officialPortalUrl;
    public String applyOnlineUrl;
    public String statusCheckUrl;
    public String helpline;
    public String highlightAmount;
    public boolean isPopular;
}
