package com.suddunagesh.yojanamitraa;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class AdMobManager {
    private static final String TAG = "AdMobManager";
    private static AdMobManager instance;
    private InterstitialAd mInterstitialAd;
    private int yojanaOpenCount = 0;

    private AdMobManager() {}

    public static synchronized AdMobManager getInstance() {
        if (instance == null) {
            instance = new AdMobManager();
        }
        return instance;
    }

    public void init(Context context) {
        MobileAds.initialize(context, initializationStatus -> {
            Log.d(TAG, "AdMob SDK Initialized successfully");
        });
        loadInterstitial(context);
    }

    public void loadInterstitial(Context context) {
        AdRequest adRequest = new AdRequest.Builder().build();
        String interstitialId = context.getString(R.string.admob_interstitial_id);

        InterstitialAd.load(context, interstitialId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
                Log.d(TAG, "Interstitial Ad Loaded successfully");
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null;
                Log.e(TAG, "Interstitial Ad Failed to Load: " + loadAdError.getMessage());
            }
        });
    }

    public void onYojanaOpened(Activity activity, Runnable onComplete) {
        yojanaOpenCount++;
        // Show Interstitial on every 3rd Yojana open as required
        if (yojanaOpenCount % 3 == 0 && mInterstitialAd != null) {
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    mInterstitialAd = null;
                    loadInterstitial(activity);
                    if (onComplete != null) onComplete.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    mInterstitialAd = null;
                    loadInterstitial(activity);
                    if (onComplete != null) onComplete.run();
                }
            });
            mInterstitialAd.show(activity);
        } else {
            if (onComplete != null) onComplete.run();
        }
    }
}
