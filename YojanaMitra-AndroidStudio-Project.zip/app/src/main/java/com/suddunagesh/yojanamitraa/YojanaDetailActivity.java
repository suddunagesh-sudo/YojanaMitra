package com.suddunagesh.yojanamitraa;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class YojanaDetailActivity extends AppCompatActivity {
    private YojanaModel yojana;
    private AdView detailAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yojana_detail);

        yojana = (YojanaModel) getIntent().getSerializableExtra("yojana_data");
        if (yojana == null) {
            finish();
            return;
        }

        // Increment count and show Interstitial every 3rd open
        AdMobManager.getInstance().onYojanaOpened(this, null);

        Toolbar toolbar = findViewById(R.id.detailToolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(yojana.name_hi);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        TextView tvTitle = findViewById(R.id.tvDetailTitle);
        TextView tvTagline = findViewById(R.id.tvDetailTagline);
        TextView tvBenefits = findViewById(R.id.tvDetailBenefits);
        TextView tvEligibility = findViewById(R.id.tvDetailEligibility);
        TextView tvDocuments = findViewById(R.id.tvDetailDocuments);
        TextView tvHowToApply = findViewById(R.id.tvDetailHowToApply);
        Button btnApplyOnline = findViewById(R.id.btnApplyOnline);
        Button btnShare = findViewById(R.id.btnShare);

        tvTitle.setText(yojana.name_hi);
        tvTagline.setText(yojana.tagline_hi);

        StringBuilder sbBenefits = new StringBuilder();
        if (yojana.benefits_hi != null) {
            for (String b : yojana.benefits_hi) {
                sbBenefits.append("• ").append(b).append("

");
            }
        }
        tvBenefits.setText(sbBenefits.toString().trim());

        StringBuilder sbEligibility = new StringBuilder();
        if (yojana.eligibility_hi != null) {
            for (String e : yojana.eligibility_hi) {
                sbEligibility.append("• ").append(e).append("

");
            }
        }
        tvEligibility.setText(sbEligibility.toString().trim());

        StringBuilder sbDocs = new StringBuilder();
        if (yojana.documents_hi != null) {
            for (String d : yojana.documents_hi) {
                sbDocs.append("✓ ").append(d).append("
");
            }
        }
        tvDocuments.setText(sbDocs.toString().trim());

        StringBuilder sbApply = new StringBuilder();
        if (yojana.howToApply_hi != null) {
            int step = 1;
            for (String h : yojana.howToApply_hi) {
                sbApply.append(step++).append(". ").append(h).append("

");
            }
        }
        tvHowToApply.setText(sbApply.toString().trim());

        btnApplyOnline.setOnClickListener(v -> {
            String url = (yojana.applyOnlineUrl != null && !yojana.applyOnlineUrl.isEmpty()) 
                ? yojana.applyOnlineUrl : yojana.officialPortalUrl;
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(browserIntent);
        });

        btnShare.setOnClickListener(v -> {
            String shareBody = "🔥 *YOJANA MITRA - सरकारी योजना हेल्प* 🔥

"
                    + "📋 योजना: " + yojana.name_hi + "
"
                    + "💡 लाभ: " + yojana.tagline_hi + "
"
                    + "🌐 आवेदन लिंक: " + yojana.officialPortalUrl + "

"
                    + "📲 ऐसी सभी सरकारी योजनाओं की जानकारी के लिए आज ही डाउनलोड करें 'योजना मित्र' ऐप!";
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, yojana.name_hi);
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(shareIntent, "योजना शेयर करें:"));
        });

        // Banner Ad
        detailAdView = findViewById(R.id.detailAdView);
        AdRequest adRequest = new AdRequest.Builder().build();
        detailAdView.loadAd(adRequest);
    }

    @Override
    protected void onDestroy() {
        if (detailAdView != null) {
            detailAdView.destroy();
        }
        super.onDestroy();
    }
}
