package com.suddunagesh.yojanamitraa;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class YojanaAdapter extends RecyclerView.Adapter<YojanaAdapter.ViewHolder> {
    private final Context context;
    private List<YojanaModel> schemeList = new ArrayList<>();

    public YojanaAdapter(Context context) {
        this.context = context;
    }

    public void setList(List<YojanaModel> list) {
        this.schemeList = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_yojana, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        YojanaModel item = schemeList.get(position);
        holder.tvTitle.setText(item.name_hi);
        holder.tvTagline.setText(item.tagline_hi);
        holder.tvCategory.setText(item.categoryName_hi);
        holder.tvState.setText(item.stateName_hi);
        holder.tvHighlight.setText(item.highlightAmount != null ? item.highlightAmount : "");

        View.OnClickListener listener = v -> {
            Intent intent = new Intent(context, YojanaDetailActivity.class);
            intent.putExtra("yojana_data", item);
            context.startActivity(intent);
        };

        holder.itemView.setOnClickListener(listener);
        holder.btnViewDetails.setOnClickListener(listener);
    }

    @Override
    public int getItemCount() {
        return schemeList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvTagline, tvCategory, tvState, tvHighlight;
        Button btnViewDetails;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvTagline = itemView.findViewById(R.id.tvTagline);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvState = itemView.findViewById(R.id.tvState);
            tvHighlight = itemView.findViewById(R.id.tvHighlight);
            btnViewDetails = itemView.findViewById(R.id.btnViewDetails);
        }
    }
}
