# Add project specific ProGuard rules here.
-keep class com.suddunagesh.yojanamitraa.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
