# YOJANA MITRA - सरकारी योजना हेल्प (Android Studio Project)

**Package Name:** `com.suddunagesh.yojanamitraa`  
**Target SDK:** Android 34 (Android 14) / Min SDK 21 (Android 5.0)  
**AdMob SDK:** `22.6.0`  

---

## 📱 Features Included:
1. **Part 1 - Home Blog WebView:**
   - Pre-configured to load `https://surgujasarkariyojanahelp.blogspot.com`
   - Pull-to-refresh (`SwipeRefreshLayout`)
   - Hardware accelerated WebSettings with DOM & LocalStorage
   - Custom back-press navigation handling
   - Error page / No-Internet offline fallback

2. **Part 2 - Native 50+ Schemes Database (100% Offline):**
   - Full JSON database embedded in `app/src/main/assets/schemes.json`
   - Complete schemes list with instant search filtering
   - Dedicated `YojanaDetailActivity` with:
     - Benefits, Eligibility, Required Documents, Step-by-Step How to Apply
     - Direct browser Intent to Official Portal (`Apply Online`)
     - WhatsApp Share Intent with formatted Hindi message

3. **AdMob Monetization (100% Compliant):**
   - App ID: `ca-app-pub-8356970466908969~8353887257`
   - Banner Ad ID: `ca-app-pub-8356970466908969/6911529210` (Fixed at bottom)
   - Interstitial Ad ID: `ca-app-pub-8356970466908969/3771105418` (Triggered on every 3rd scheme open)
   - Rewarded Ad ID: `ca-app-pub-8356970466908969/4876392810`

---

## 🚀 How to Build & Generate Signed APK:
1. Extract this ZIP file.
2. Open **Android Studio** (Koala, Ladybug, Iguana or Hedgehog).
3. Select **File -> Open** and select the extracted folder.
4. Let Gradle sync dependencies automatically.
5. Connect your Android phone via USB or start an Emulator.
6. Click **Run (Shift + F10)**.
7. To generate production APK / Bundle:
   - Go to **Build -> Generate Signed Bundle / APK**
   - Choose **APK** or **Android App Bundle (.aab)**
   - Sign with your Keystore and publish to Google Play Console!
